package org.iotmit.mapper;

import java.util.List;

import org.iotmit.domain.MemberVO;

public interface MemberMapper {

	public MemberVO read(String userid);

}
